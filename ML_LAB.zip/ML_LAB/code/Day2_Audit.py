


# ----------------------------------------------------------------------------import pandas as pd
import numpy as np

df = pd.read_csv("loan_default_day2.csv")

df.head()
df.shape
df.info()
df.describe()

df["employment_type"].value_counts()
# df["region"].value_counts()
# df["risk_flag"].value_counts()
# df["late_but_repaid"].value_counts()

df.isna().mean() * 100
df.isna().sum()
df.groupby(df["monthly_income"].isna())["defaulted_12m"].mean()

data = df.copy()
data["loan_date"] = pd.to_datetime(data["loan_date"])
data["account_closed_date"] = pd.to_datetime(data["account_closed_date"])
data["loan_date"] = data["loan_date"].map(lambda x: x.toordinal())
data["account_closed_date"] = data["account_closed_date"].map(
    lambda x: x.toordinal() if pd.notna(x) else np.nan
)
X = data.drop("defaulted_12m", axis=1)
y = data["defaulted_12m"]
X = pd.get_dummies(X, drop_first=True)
X = X.fillna(X.median(numeric_only=True))

from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import cross_val_score

model = GradientBoostingClassifier(random_state=42)

scores = cross_val_score(
    model,
    X,
    y,
    cv=5,
    scoring="roc_auc"
)

scores.mean()

X1 = X.drop("collection_calls", axis=1)

scores = cross_val_score(
    model,
    X1,
    y,
    cv=5,
    scoring="roc_auc"
)

scores.mean()

X2 = X.drop("recovery_amount", axis=1)

scores = cross_val_score(
    model,
    X2,
    y,
    cv=5,
    scoring="roc_auc"
)

scores.mean()

X3 = X.drop("account_closed_date", axis=1)

scores = cross_val_score(
    model,
    X3,
    y,
    cv=5,
    scoring="roc_auc"
)

scores.mean()

X4 = X.drop("risk_flag_low", axis=1)

scores = cross_val_score(
    model,
    X4,
    y,
    cv=5,
    scoring="roc_auc"
)

scores.mean()

X5 = X.drop("late_but_repaid_Y", axis=1)

scores = cross_val_score(
    model,
    X5,
    y,
    cv=5,
    scoring="roc_auc"
)

scores.mean()

X6 = X.drop("loan_id", axis=1)

scores = cross_val_score(
    model,
    X6,
    y,
    cv=5,
    scoring="roc_auc"
)

scores.mean()

df.duplicated().sum()

df[df.duplicated(keep=False)]

temp = df.copy()

temp["name_clean"] = (
    temp["applicant_name"]
    .str.strip()
    .str.lower()
)

near = temp[temp.duplicated(
    subset=["name_clean", "age", "employment_type",
            "employment_years", "loan_amount",
            "credit_score", "region"],
    keep=False
)]

near.shape

suspicious = df[
    ((df["collection_calls"] > 0) & (df["defaulted_12m"] == 0)) |
    ((df["recovery_amount"] > 0) & (df["defaulted_12m"] == 0)) |
    ((df["risk_flag"] == "high") & (df["defaulted_12m"] == 0))
]

suspicious[[
    "loan_id",
    "collection_calls",
    "recovery_amount",
    "risk_flag",
    "late_but_repaid",
    "defaulted_12m"
]].head(20)

X5 = X.drop("late_but_repaid_Y", axis=1)

scores = cross_val_score(
    model,
    X5,
    y,
    cv=5,
    scoring="roc_auc"
)

scores.mean()

temp = df.copy()

temp["name_clean"] = (
    temp["applicant_name"]
    .str.strip()
    .str.lower()
)

temp["emp_clean"] = (
    temp["employment_type"]
    .str.lower()
    .str.replace("-", " ", regex=False)
    .str.replace(r"\s+", " ", regex=True)
    .str.strip()
)

temp["income_round"] = temp["monthly_income"].round(-3)

keys = [
    "name_clean",
    "age",
    "emp_clean",
    "employment_years",
    "income_round",
    "loan_amount",
    "loan_date",
    "credit_score",
    "region",
    "collection_calls",
    "recovery_amount",
    "account_closed_date",
    "risk_flag",
    "late_but_repaid",
    "defaulted_12m"
]

candidate = temp[temp.duplicated(subset=keys, keep=False)]

candidate.shape

exact_mask = df.duplicated(keep=False)

near_only = candidate[~exact_mask]

near_only.shape

df_no_dup = df.drop_duplicates().copy()

data2 = df_no_dup.copy()

data2["loan_date"] = pd.to_datetime(data2["loan_date"])
data2["account_closed_date"] = pd.to_datetime(data2["account_closed_date"])

data2["loan_date"] = data2["loan_date"].map(lambda x: x.toordinal())
data2["account_closed_date"] = data2["account_closed_date"].map(
    lambda x: x.toordinal() if pd.notna(x) else np.nan
)

X_no_dup = data2.drop("defaulted_12m", axis=1)
y_no_dup = data2["defaulted_12m"]

X_no_dup = pd.get_dummies(X_no_dup, drop_first=True)
X_no_dup = X_no_dup.fillna(X_no_dup.median(numeric_only=True))

scores = cross_val_score(
    model,
    X_no_dup,
    y_no_dup,
    cv=5,
    scoring="roc_auc"
)

scores.mean()

suspicious = df[
    (
        ((df["recovery_amount"] > 0) & (df["defaulted_12m"] == 0))
        |
        ((df["collection_calls"] >= 5) & (df["defaulted_12m"] == 0))
        |
        ((df["risk_flag"] == "high") & (df["defaulted_12m"] == 0))
    )
]

rows20 = suspicious[[
    "loan_id",
    "collection_calls",
    "recovery_amount",
    "risk_flag",
    "late_but_repaid",
    "defaulted_12m"
]].head(20)

rows20

rows20 = suspicious[[
    "loan_id",
    "region",
    "collection_calls",
    "recovery_amount",
    "risk_flag",
    "late_but_repaid",
    "defaulted_12m"
]].head(20)

rows20

pd.crosstab(
    df["late_but_repaid"],
    [df["region"], df["defaulted_12m"]]
)
