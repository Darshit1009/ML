# Converted from Jupyter Notebook
# Code cells are preserved in their original order.
# Markdown cells and notebook outputs are not included.



# ----------------------------------------------------------------------------import numpy as np
import matplotlib.pyplot as plt

from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# always normalize dataset containing multiple features
# logistic regression will first be applied to original dataset with 4 features and then it's applied to the PCA transformed dataset (2 features) in order to compare accuracies.

iris = load_iris()

X = iris.data
y = iris.target

feature_names = iris.feature_names
target_names = iris.target_names

print("Original dataset shape:", X.shape)
print("Number of features:", X.shape[1])
print("Number of classes:", len(target_names))

scaler = StandardScaler()

X_scaled = scaler.fit_transform(X)

print("\nAfter standardization:")
print("Mean of features:", X_scaled.mean(axis=0))
print("Standard deviation:", X_scaled.std(axis=0))

# to reduce the biasedness over certain features, introduced by the data.
# fit() : This step calculates the internal parameters or statistics required to transform data.
# For example, if you are scaling features, fit() will calculate the mean and standard deviation of your columns. It does not alter the data itself.
# transform() : This step uses the parameters learned by the fit() method and applies them to modify the data. For instance, it uses the calculated mean and standard deviation to actually scale the data values.

# instead of writing two separate lines of code (transformer.fit(X) followed by transformer.transform(X)), fit_transform() computes the parameters and outputs the transformed data all at once.


# after normalization mean will always be 0 and variance will always be 1. and if variance is 1, standard deviation will also be 1.

pca = PCA(n_components=2)

X_pca = pca.fit_transform(X_scaled)

print("\nPCA transformed shape:", X_pca.shape)

print("\nExplained variance ratio:")
print(pca.explained_variance_ratio_)

print("\nTotal variance retained:",
      pca.explained_variance_ratio_.sum())

#Principal component plotings
plt.figure(figsize=(8, 6))

for class_id, class_name in enumerate(target_names):

    plt.scatter(
        X_pca[y == class_id, 0],
        X_pca[y == class_id, 1],
        label=class_name,
        alpha=0.7
    )

plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.title("Iris Dataset after PCA (4D → 2D)")
plt.legend()
plt.grid(True)
plt.show()

#Principal component based variance
pca_full = PCA()

X_pca_full = pca_full.fit_transform(X_scaled)

explained_variance = pca_full.explained_variance_ratio_

print("\nExplained variance of all principal components:")

for i, variance in enumerate(explained_variance):
    print(
        f"PC{i+1}: {variance:.4f} "
        f"({variance*100:.2f}%)"
    )

# Same train-test split for fair comparison

X_train, X_test, y_train, y_test = train_test_split(
    X_scaled,
    y,
    test_size=0.2,
    random_state=42

)

# Logistic Regression using ORIGINAL 4 features


model_original = LogisticRegression(max_iter=1000)

model_original.fit(X_train, y_train)

y_pred_original = model_original.predict(X_test)

accuracy_original = accuracy_score(
    y_test,
    y_pred_original
)

#After PCA
pca_2 = PCA(n_components=2)

X_train_pca = pca_2.fit_transform(X_train)
X_test_pca = pca_2.transform(X_test)

# Logistic Regression using ONLY 2 PCA features

model_pca = LogisticRegression(max_iter=1000)

model_pca.fit(X_train_pca, y_train)

y_pred_pca = model_pca.predict(X_test_pca)

accuracy_pca = accuracy_score(
    y_test,
    y_pred_pca
)


print("PCA EFFECTIVENESS")


print(
    f"Original features: 4"
)

print(
    f"PCA features:      2"
)

print(
    f"\nAccuracy using original 4 features: "
    f"{accuracy_original:.4f}"
)

print(
    f"Accuracy using 2 PCA features:      "
    f"{accuracy_pca:.4f}"
)

print(
    f"\nVariance retained by 2 PCs: "
    f"{pca_2.explained_variance_ratio_.sum()*100:.2f}%"
)
