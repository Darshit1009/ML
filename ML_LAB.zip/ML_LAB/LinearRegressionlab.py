


# ----------------------------------------------------------------------------import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

data=pd.read_csv("/content/train.csv")

data.head()

data.shape

data.describe()

# generate boxplot for x and y
# conceptual understanding of determinant and why determinants of non-square matrices do not exist?
