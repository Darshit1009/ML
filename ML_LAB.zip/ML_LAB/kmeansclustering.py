


# ----------------------------------------------------------------------------import numpy as np
numbers=np.arange(1,101)
np.random.seed(42) # this function leads to static output for the random numbers (means the set of random numbers does not change everytime we run the code)
demo=np.random.choice(numbers,10,replace=False)
print(demo)

import numpy as np
import matplotlib.pyplot as plt

from sklearn.datasets import load_iris
from sklearn.cluster import KMeans

iris = load_iris()

X = iris.data

print("Dataset Shape:", X.shape)
print("Feature Names:", iris.feature_names)

inertia = []

K = range(1, 11)

for k in K:

    kmeans = KMeans(
        n_clusters=k,
        random_state=42,
        n_init=10
    )

    kmeans.fit(X)

    inertia.append(kmeans.inertia_)


# Plot Elbow Curve

plt.figure(figsize=(8, 5))

plt.plot(K, inertia, marker='o')

plt.xlabel("Number of Clusters (K)")
plt.ylabel("Inertia")

plt.title("Elbow Method")

plt.xticks(K)

plt.show()

kmeans = KMeans(
    n_clusters=3,
    random_state=42,
    n_init=10
)

labels = kmeans.fit_predict(X)

centroids = kmeans.cluster_centers_

print("\nCentroids:")
print(centroids)


# --------------------------------------------------
# 5. Visualize Clusters
# --------------------------------------------------

plt.figure(figsize=(8, 6))

plt.scatter(
    X[:, 0],
    X[:, 1],
    c=labels,
    s=50
)

# Plot centroids

plt.scatter(
    centroids[:, 0],
    centroids[:, 1],
    marker='X',
    s=200,
    edgecolor='black',
    label='Centroids'
)

plt.xlabel("Sepal Length")
plt.ylabel("Sepal Width")

plt.title("K-Means Clustering on Iris Dataset")

plt.legend()

plt.show()
