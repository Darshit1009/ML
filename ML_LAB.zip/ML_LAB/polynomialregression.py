# Converted from Jupyter Notebook
# Code cells are preserved in their original order.
# Markdown cells and notebook outputs are not included.



# ----------------------------------------------------------------------------import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler,PolynomialFeatures
from sklearn.linear_model import LinearRegression

data=load_diabetes()

data

x=pd.DataFrame(data.data, columns=data.feature_names)
y=data.target

x.head()

# considering only a subset of total features right now

features=['bmi','bp','s5']
X=x[features]

# train test split feature accepts two arguments: dataset and proportion of split
# it divides entire dataset into 4 parts: first X and Y - X means input features and Y means output
# secondly into training and testing parts: for example if proportion value is 0.2 then 20% of the entire dataset will be assigned for testing and remaining 80 % for training

scaler=StandardScaler()
X_train, X_test, Y_train, Y_test=train_test_split(X, Y, test_size=0.2)
X_train=scaler.fit_transform(X_train)
X_test=scaler.transform(X_test)

def costfunction(y_actual, y_predicted):
  m=len(y_actual)
  sum=np.sum((y_predicted-y_actual)**2)
  return (sum/2*m)

degree=range(1,7)
cost_values=[]
for d in degree:
  poly=PolynomialFeatures(degree=d,include_bias=False)
  x_train_poly=poly.fit_transform(X_train)
  x_test_poly=poly.transform(X_test)
