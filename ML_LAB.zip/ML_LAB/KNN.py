


# ----------------------------------------------------------------------------import pandas as pd
import numpy as np
from sklearn.datasets import load_iris
import matplotlib.pyplot as plt

data=load_iris()

x=data.data
y=data.data
K=5
distances={}

data=pd.DataFrame(data=data.data, columns=data.feature_names)

data

test=data.iloc[0,:]

test

for i in range(len(data)):
  for j in range(0,4):
    x=(test[j])**2+(data.loc[i,j])**2
    distances[i]=x
