



# ----------------------------------------------------------------------------# RANDOM FOREST
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn import datasets

iris=datasets.load_iris()

data=pd.DataFrame({"sepal_length":iris.data[:,0],
                   "sepal_width":iris.data[:,1],
                   "petal_length":iris.data[:,2],
                   "petal_width":iris.data[:,3],
                   "output":iris.target
                   })

data

# SPLITTING THE DATASET IN TRAIN-TEST SUBSETS

from sklearn.model_selection import train_test_split

# feature and output splitting

X=data[['sepal_length', 'sepal_width','petal_length','petal_width']]
Y=data['output']

X_train, X_test, Y_train, Y_test= train_test_split(X,Y,test_size=0.2, random_state=42)

# defining model

from sklearn.ensemble import RandomForestClassifier

model=RandomForestClassifier(n_estimators=100)

model.fit(X_train,Y_train)

from sklearn.metrics import accuracy_score
y_pred=model.predict(X_test)
print(accuracy_score(Y_test, y_pred))

a=np.arange(50,500,50)
accuracy_values=[]
for i in a:
  model=RandomForestClassifier(n_estimators=i)
  model.fit(X_train, Y_train)
  y_pred=model.predict(X_test)
  accuracy_values.append(accuracy_score(Y_test, y_pred))

plt.plot(a,accuracy_values)
plt.show()

# VISUALIZATION OF TREES
from sklearn.tree import export_graphviz
import pydot

tree=model.estimators_[10]
export_graphviz(tree, out_file='tree.dot', feature_names=iris.feature_names)
(graph,)=pydot.graph_from_dot_file('tree.dot')
graph.write_png('tree.png')

# creating graph from the generated dot (decision format) file and then exporting that graph file as png
