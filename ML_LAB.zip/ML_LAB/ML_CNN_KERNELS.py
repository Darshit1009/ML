



# ----------------------------------------------------------------------------import cv2
import pandas as pd
import numpy as np
from scipy.ndimage import convolve
import matplotlib.pyplot as plt

image=cv2.imread('/content/images (1).jpg', cv2.IMREAD_GRAYSCALE)
# converting to grayscale because we are performing 2 dimennsional convolution

plt.figure(figsize=(6,4))
plt.imshow(image,cmap='gray')

sharpen=[[0,1,0],[1,-5,1],[0,1,0]]
# kernel
im=np.array(image, dtype=float)
# the new value for each pixel will be in decimal/fraction because we will be dividing the product of pixel value and kernel value by the sum of kernel value
# which will give us fractional value.
img2=convolve(im, sharpen)

blur=np.ones((7,7),dtype=float)/49
# increasing the size of the kernel will increase the bluriness of the image. for example (5,5) will give more blurry image than (3,3)
# and (7,7) will result in even more blur images

plt.imshow(img2, cmap='gray')

image3=convolve(image,blur)
plt.imshow(image3,cmap='gray')

# HOMEWORK: FIND OUT THE KERNEL FOR RADIAL BLUR (only the subject is clear, rest everything is l)
