

# ----------------------------------------------------------------------------import os
os.environ['KAGGLE_USERNAME'] = 'darshitkacha'
os.environ['KAGGLE_KEY']='KGAT_3cd4c8c26b9e789a8aa9291307046d2c'

!pip install -q kaggle

!kaggle datasets download shivamb/netflix-shows

!unzip -q netflix-shows.zip

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df=pd.read_csv("/content/netflix_titles.csv")

df

director_counts = (
    df[df['type'] == 'Movie']
    .dropna(subset=['director'])
    .groupby('director')
    .size()
    .sort_values(ascending=False)
)

top_directors = director_counts.head(10)

plt.figure(figsize=(12, 6))
plt.bar(top_directors.index, top_directors.values)
plt.title("Top 10 Directors by Number of Movies")
plt.xlabel("Director")
plt.ylabel("Number of Movies")
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()

top_cast = df['cast'].value_counts().head(10)
sns.barplot(x=top_cast.values,y=top_cast.index)

top_country = df['country'].value_counts().head(10)
sns.barplot(x=top_country.values,y=top_country.index)

top_country = df['country'].value_counts().head(10)
top_country = top_country.drop('Japan')
sns.barplot(x=top_country.values,y=top_country.index)

df[df['country'].isin(['India', 'United States'])].groupby(['country', 'type']).size()

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv("/content/train (1).csv")

data

#SPLITING THE INPUT AND OUTPUT FEATURES
x_value=data.iloc[:,0:1]
y_value=data.iloc[:,1:2]
x_box=x_value.boxplot(column=['x'])
y_box=y_value.boxplot(column=['y'])

def hypothesis(theta_array,x):
  return (theta_array[0]+theta_array[1]*x)

def cost_function(theta_array,x,y,m):
  total_error=0
  for i in range(m):
    total_error+=(theta_array[0]+theta_array[1]*x[i]-y[i])**2
  return (total_error/(2*m))

def gradient_descent(theta_array,x,y,m,alpha):
  sum_0,sum_1=0,0
  for i in range(m):
    sum_0+=((theta_array[0]+theta_array[1]*x[i])-y[i])
    sum_1+=x[i]*((theta_array[0]+theta_array[1]*x[i])-y[i])
  update_theta0=theta_array[0]-(alpha/m)*sum_0
  update_theta1=theta_array[1]-(alpha/m)*sum_1
  new_theta=[update_theta0,update_theta1]
  return new_theta

def training(x,y,alpha,iters):
  theta_0,theta_1=0,0
  theta_array=[theta_0,theta_1]
  m=x.size
  cost_value=[]
  for i in range(iters):
    theta_array=gradient_descent(theta_array,x,y,m,alpha)
    cost_value.append(cost_function(theta_array,x,y,m))
    y_new=theta_array[0]+theta_array[1]*x
    plt.plot(x,y_new,'r')
    plt.scatter(x,y)
    plt.show()

  x=np.arange(0,len(cost_value),step=1)
  plt.plot(x,cost_value)
  plt.show()
  return theta_array

clean_data=data.dropna()

clean_data.describe()

x_train=clean_data['x']
y_train=clean_data['y']

alpha=0.0000001
iters=50

x_t=x_train.values
y_t=y_train.values

training(x_t,y_t,alpha,iters)

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler,PolynomialFeatures
from sklearn.linear_model import LinearRegression
data = load_diabetes()

data

x=pd.DataFrame(data.data,columns=data.feature_names)
y=data.target

x

features=['bmi','bp','s5']
X=x[features]

X

X_train,X_test,Y_train,Y_test = train_test_split(X,y,test_size=0.2)

scaler = StandardScaler()
X_train=scaler.fit_transform(X_train)
X_test=scaler.transform(X_test)

def costfunction(y_actual,y_predict):
  m=len(y_actual)
  summ = np.sum((y_predict-y_actual)**2)
  return (summ/(2*m))

#polynomial regression
degree = range(1,7)
cost_values = []
for deg in degree:
  poly = PolynomialFeatures(degree=deg,include_bias=False)
  x_train_poly = poly.fit_transform(X_train)
  x_test_poly = poly.transform(X_test)

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn import datasets

iris = datasets.load_iris()

data = pd.DataFrame({"sepal_length":iris.data[:,0],
                     "sepal_width":iris.data[:,1],
                     "petal_length":iris.data[:,2],
                     "petal_width":iris.data[:,3],
                     "output":iris.target})

data

from sklearn.model_selection import train_test_split
x = data[['sepal_length','sepal_width','petal_length','petal_width']]
y = data['output']

x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.01,random_state=42)

from sklearn.ensemble import RandomForestClassifier

model = RandomForestClassifier(n_estimators=100)

model.fit(x_train,y_train)

y_pred = model.predict(x_test)
from sklearn.metrics import accuracy_score
accuracy_score(y_test,y_pred)

ans = []
x = []
for i in range(50,501,50):
  x.append(i)
  model = RandomForestClassifier(n_estimators=100)
  model.fit(x_train,y_train)
  y_pred = model.predict(x_test)
  from sklearn.metrics import accuracy_score
  ans.append(accuracy_score(y_test,y_pred))

plt.plot(x,ans)
plt.show()

from sklearn.tree import export_graphviz
import pydot
tree = model.estimator_[10]
export_graphviz(tree,out_file="/content/tree.dot",feature_names = iris.feature_names)
(graph,)=pydot.graph_from_dot_file("tree.dot")
graph.write_png("tree.png")
